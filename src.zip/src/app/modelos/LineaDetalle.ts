export class LineaDetalle {

    public constructor(
        public descripcion:string,
        public importeUnitario: number,
        public unidades: number,
        public importeTotal
    ){

    }

}