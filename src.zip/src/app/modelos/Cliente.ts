export class Cliente {
    constructor(public id: number,
        public cliente: string) { }

}