export class ElementoLista {
    public constructor(
        public id:number,
        public cliente:string,
        public importeTotalConIva:number
    ){

    }
}